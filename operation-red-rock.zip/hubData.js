/**
 * hubData.js
 * All static content, copy, numbers, and defaults for the Operation Red Rock Mission Hub.
 * Edit this file to update text, translate strings, or rebalance mission/rover metadata.
 */

export const STORAGE_KEY = 'operationRedRock.v1';
export const INTRO_VIDEO_SRC = '/assets/aistudio/Video_Project_no_subtitles_7615538a.mp4';

export const HUB_COPY = {
  gameTitle: 'OPERATION RED ROCK',
  gameSubtitle: 'Planetary Rover Training & Mars Sample Retrieval',
  loadingTitle: 'OPERATION RED ROCK',
  loadingSubtitle: 'Preparing surface telemetry and rover bay',
  loadingStatusText: 'Loading mission assets',
  loadingReadyText: 'Ready for launch',
  navItems: [
    { id: 'home', label: 'Home' },
    { id: 'garage', label: 'Garage' },
    { id: 'missions', label: 'Missions' },
    { id: 'codex', label: 'Codex' },
    { id: 'settings', label: 'Settings' },
  ],
  home: {
    launchLabel: 'Launch',
    launchLockedHint: 'Waiting for mission assets to finish loading...',
    previewHint: 'Drag to rotate rover',
    callsignLabel: 'Callsign',
    roverLabel: 'Assigned Rover',
    nextLabel: 'Next',
    progressLabel: 'Campaign Progress',
  },
  garage: {
    heading: 'Rover Bay',
    subheading: 'Select an available rover and review equipped workshop hardware.',
    statsNote: 'Ratings represent simplified gameplay performance tiers (1-5).',
    statLabels: {
      battery: 'Battery',
      speed: 'Speed',
      climbing: 'Climbing',
      cargo: 'Cargo',
    },
    upgradesHeading: 'Equipped Workshop Upgrades',
    ownedText: 'Equipped',
    unownedText: 'Not crafted',
    lockedBadge: 'Coming soon',
    selectedText: 'Selected',
    availableText: 'Select rover',
  },
  missions: {
    heading: 'Mission Control',
    subheading: 'Train on Earth in the Atacama Desert, craft upgrades, then launch to Gale Crater.',
    startButton: 'Start',
    lockedButton: 'Locked',
    objectivesLabel: 'Mission Objectives',
    bestScoreLabel: 'Best Score',
    statusLabels: {
      locked: 'Locked',
      available: 'Available',
      completed: 'Completed',
    },
    redRockUnlockRule: 'Complete Training 1, Training 2, and Training 3 to unlock.',
  },
  codex: {
    heading: 'Field Codex',
    subheading: 'Planetary science notes unlocked as you complete training and Mars operations.',
    lockedTitle: 'Classified Entry',
    lockedHintPrefix: 'Unlocks:',
    achievementsHeading: 'Mission Achievements',
    achievementUnlocked: 'Unlocked',
    achievementLocked: 'Locked',
  },
  settings: {
    heading: 'System Settings',
    subheading: 'Configure audio, rendering quality, callsign, and local save data.',
    musicLabel: 'Music',
    sfxLabel: 'Sound Effects',
    qualityLabel: 'Graphics Quality',
    qualityOptions: ['Low', 'Medium', 'High'],
    callsignLabel: 'Pilot Callsign',
    callsignHelp: 'Letters and numbers only, up to 12 characters.',
    replayIntroLabel: 'Replay intro',
    creditsLabel: 'Credits',
    resetLabel: 'Reset progress',
    resetConfirmTitle: 'Reset all progress?',
    resetConfirmBody: 'This clears completed missions, stars, best scores, workshop upgrades, Codex entries, and achievements. Your audio and quality settings are kept.',
    resetConfirmYes: 'Confirm reset',
    resetConfirmCancel: 'Cancel',
    resetDoneMessage: 'Mission progress has been reset.',
  },
  credits: {
    heading: 'Credits',
    teamHeading: 'Hackathon Team',
    toolsHeading: 'Tools & Technology',
    attributionHeading: 'Data & Imagery Attribution',
    attributionLine: 'Terrain based on a Gale Crater model. Mars imagery credit: NASA/JPL-Caltech.',
    disclaimerLine: 'This game is not affiliated with or endorsed by NASA.',
    closeLabel: 'Close',
  },
  pause: {
    heading: 'Mission Paused',
    subheading: 'Surface operations suspended.',
    resumeLabel: 'Resume',
    restartLabel: 'Restart',
    backToHubLabel: 'Back to hub',
  },
  intro: {
    skipLabel: 'Skip intro',
    muteLabel: 'Mute',
    unmuteLabel: 'Unmute',
  },
};

export const LOADING_TIPS = [
  'Tip: Plan routes across gentle slopes to conserve rover battery power.',
  'Tip: Earth analog sites like the Atacama Desert help engineers test Mars hardware.',
  'Tip: Visit the Workshop before launching to Gale Crater to install vital upgrades.',
  'Tip: Dust accumulation reduces solar charging efficiency during long drives.',
  'Tip: Drag the 3D rover preview on Home or in the Garage to inspect your vehicle.',
];

/**
 * NOTE: Robot stats below (1 to 5 scale) are simplified gameplay numbers for balance
 * and UI comparison, NOT real-world rover engineering specifications.
 */
export const ROBOTS = [
  {
    id: 'scout',
    name: 'Scout',
    role: 'Light Recon Chassis',
    description: 'Compact high-speed platform tuned for rapid scouting across flat terrain.',
    locked: true,
    lockReason: 'Coming soon',
    stats: {
      battery: 3,
      speed: 5,
      climbing: 2,
      cargo: 1,
    },
    palette: {
      body: 0x3b82f6,
      trim: 0x1e293b,
      accent: 0x5dcaa5,
    },
  },
  {
    id: 'explorer',
    name: 'Explorer',
    role: 'All-Terrain Science Rover',
    description: 'Balanced six-wheel rocker-bogie rover certified for Atacama and Gale Crater.',
    locked: false,
    lockReason: '',
    stats: {
      battery: 4,
      speed: 3,
      climbing: 4,
      cargo: 2,
    },
    palette: {
      body: 0xd99b26,
      trim: 0x263047,
      accent: 0xe2572b,
    },
  },
  {
    id: 'hauler',
    name: 'Hauler',
    role: 'Heavy Sample Carrier',
    description: 'Reinforced heavy-payload frame built for steep grades and multi-core transport.',
    locked: true,
    lockReason: 'Coming soon',
    stats: {
      battery: 5,
      speed: 2,
      climbing: 3,
      cargo: 4,
    },
    palette: {
      body: 0x8a90a2,
      trim: 0x1a2238,
      accent: 0xe2572b,
    },
  },
];

export const WORKSHOP_UPGRADES = [
  { id: 'wheels', name: 'Off-Road Wheels', hint: 'Improved traction on loose regolith' },
  { id: 'scanner', name: 'Scanner', hint: 'Highlights nearby mineral samples' },
  { id: 'battery', name: 'Large Battery', hint: 'Increases maximum stored energy' },
  { id: 'solar', name: 'Solar Panel', hint: 'Boosts daytime recharge rate' },
  { id: 'dustCover', name: 'Dust Cover', hint: 'Protects joints from fine Martian dust' },
  { id: 'repairKits', name: 'Repair Kits', hint: 'Emergency field hull restoration' },
];

export const MISSIONS = [
  {
    id: 'training1',
    title: 'Training 1: Surface Driving',
    shortTitle: 'Training 1',
    location: 'Atacama Desert',
    description: 'Learn six-wheel steering and obstacle avoidance across rocky desert flats. Reach all navigation beacons before dusk.',
    objectives: [
      'Navigate through three desert waypoint gates',
      'Avoid steep boulder hazards',
      'Reach the recovery pad intact',
    ],
    requires: [],
    lockedAlways: false,
    playable: true,
    mapStyle: 'atacama-drive',
  },
  {
    id: 'training2',
    title: 'Training 2: Battery Management',
    shortTitle: 'Training 2',
    location: 'Atacama Desert',
    description: 'Balance drive speed against power draw over rolling dunes. Recharge at solar stations to complete the out-and-back loop.',
    objectives: [
      'Reach the distant ridge relay station',
      'Recharge using solar waypoints along the route',
      'Return to base without depleting the battery',
    ],
    requires: [],
    lockedAlways: false,
    playable: true,
    mapStyle: 'atacama-battery',
  },
  {
    id: 'training3',
    title: 'Training 3: Sample Retrieval',
    shortTitle: 'Training 3',
    location: 'Atacama Desert',
    description: 'Locate mineral veins in a dry basin, scan target rocks, and haul core samples back to the mobile lab.',
    objectives: [
      'Scan target rock formations for high-grade minerals',
      'Collect required core samples',
      'Deliver samples to the extraction zone',
    ],
    requires: [],
    lockedAlways: false,
    playable: true,
    mapStyle: 'atacama-sample',
  },
  {
    id: 'workshop',
    title: 'Workshop: Rover Upgrades',
    shortTitle: 'Workshop',
    location: 'Atacama Base',
    description: 'Spend collected field resources to fabricate rover upgrades. Better wheels, batteries, and dust protection prepare you for Mars.',
    objectives: [
      'Inspect available upgrade blueprints',
      'Craft hardware modules for your rover',
      'Verify loadout readiness for orbital launch',
    ],
    requires: [],
    lockedAlways: false,
    playable: true,
    mapStyle: 'workshop-bay',
  },
  {
    id: 'redRock',
    title: 'Operation Red Rock',
    shortTitle: 'Operation Red Rock',
    location: 'Gale Crater, Mars',
    description: 'Touch down inside Gale Crater and retrieve a key bedrock sample near the foothills. Manage dust, power, and steep slopes to return safely.',
    objectives: [
      'Traverse the Gale Crater landing ellipse',
      'Retrieve the Red Rock bedrock core sample',
      'Return to the ascent vehicle with reserve battery',
    ],
    requires: ['training1', 'training2', 'training3'],
    lockedAlways: false,
    playable: true,
    mapStyle: 'gale-crater',
  },
  {
    id: 'polarRecon',
    title: 'Polar Ice Recon',
    shortTitle: 'Coming soon',
    location: 'Planum Boreum, Mars',
    description: 'Future expedition across layered polar ice deposits to test thermal drills. Available in a future mission update.',
    objectives: [
      'Coming soon in a future update',
    ],
    requires: ['redRock'],
    lockedAlways: true,
    playable: false,
    mapStyle: 'polar-locked',
  },
];

export const CODEX_ENTRIES = [
  {
    id: 'analog-sites',
    title: 'Planetary Analog Sites',
    category: 'Earth Testing',
    unlockHint: 'Available from start',
    defaultUnlocked: true,
    text: 'Engineers test Mars rovers in places like Chile\'s Atacama Desert because its dry, rocky soil closely resembles the Martian surface. Practicing in an analog site reveals mechanical and navigation issues while the rover is still reachable by humans.',
  },
  {
    id: 'why-robots',
    title: 'Why Robots Explore Mars',
    category: 'Mission Design',
    unlockHint: 'Complete Training 1',
    unlockMission: 'training1',
    defaultUnlocked: false,
    text: 'Robotic rovers do not require food, water, breathable air, or a return flight, making them ideal scouts for distant worlds. They carry miniature laboratories that analyze rocks and weather conditions directly on the surface.',
  },
  {
    id: 'gale-crater',
    title: 'Inside Gale Crater',
    category: 'Mars Geology',
    unlockHint: 'Complete Operation Red Rock',
    unlockMission: 'redRock',
    defaultUnlocked: false,
    text: 'Gale Crater is a wide impact basin on Mars with a tall layered mountain, Aeolis Mons, rising from its center. Orbiters spotted clay and sulfate minerals there, showing that liquid water once stood in the crater long ago.',
  },
  {
    id: 'battery-limits',
    title: 'Battery & Power Budgets',
    category: 'Rover Systems',
    unlockHint: 'Complete Training 2',
    unlockMission: 'training2',
    defaultUnlocked: false,
    text: 'Climbing loose slopes and running scientific drills draw heavy electrical current from a rover\'s onboard batteries. Mission planners carefully budget every meter driven so enough power remains for survival heaters overnight.',
  },
  {
    id: 'dust-storms',
    title: 'Dust Storms & Solar Panels',
    category: 'Mars Weather',
    unlockHint: 'Complete Workshop',
    unlockMission: 'workshop',
    defaultUnlocked: false,
    text: 'Fine iron-oxide dust suspended in the Martian sky scatters sunlight and gradually settles onto exposed solar arrays. Thick regional dust storms can block light for weeks, forcing solar-powered rovers into low-power hibernation.',
  },
  {
    id: 'sample-caching',
    title: 'Sample Retrieval & Caching',
    category: 'Science Ops',
    unlockHint: 'Complete Training 3',
    unlockMission: 'training3',
    defaultUnlocked: false,
    text: 'Onboard rover tools can examine rock chemistry, but Earth-based laboratories remain far more sensitive and versatile. Collecting sealed rock cores lets scientists study ancient Martian environments with future instruments.',
  },
  {
    id: 'radio-delay',
    title: 'Deep Space Signal Delay',
    category: 'Communications',
    unlockHint: 'Complete Training 1',
    unlockMission: 'training1',
    defaultUnlocked: false,
    text: 'Even at the speed of light, radio commands take several minutes to travel between Earth and Mars. Because drivers cannot joystick a rover in real time, rovers rely on pre-planned routes and onboard hazard avoidance.',
  },
  {
    id: 'cold-nights',
    title: 'Extreme Martian Nights',
    category: 'Environment',
    unlockHint: 'Complete Operation Red Rock',
    unlockMission: 'redRock',
    defaultUnlocked: false,
    text: 'Mars has a thin carbon-dioxide atmosphere that holds very little heat after sunset. Overnight temperatures drop sharply, so electronics must stay insulated inside a warm core box.',
  },
];

export const ACHIEVEMENTS = [
  {
    id: 'first-steps',
    name: 'First steps',
    condition: 'Finish Training 1',
    icon: 'wheel',
  },
  {
    id: 'round-trip',
    name: 'Round trip',
    condition: 'Finish Training 2',
    icon: 'battery',
  },
  {
    id: 'sharp-eye',
    name: 'Sharp eye',
    condition: 'Finish Training 3',
    icon: 'scanner',
  },
  {
    id: 'home-safe',
    name: 'Home safe',
    condition: 'Complete the Mars mission',
    icon: 'rocket',
  },
  {
    id: 'efficient',
    name: 'Efficient',
    condition: 'Complete Mars with > 50% battery left',
    icon: 'bolt',
  },
  {
    id: 'no-repairs',
    name: 'No repairs',
    condition: 'Complete Mars without using a repair kit',
    icon: 'shield',
  },
];

export const CREDITS_DATA = {
  team: [
    { role: 'Mission Hub & UI', name: 'Mission Systems Lead (Placeholder)' },
    { role: 'Rover & Physics', name: 'Robotics Engineer (Placeholder)' },
    { role: 'Terrain & Mars Environment', name: '3D World Designer (Placeholder)' },
    { role: 'Audio & Cinematics', name: 'Sound & Intro Lead (Placeholder)' },
  ],
  tools: [
    'Three.js (WebGL 3D Engine)',
    'HTML5 2D Canvas',
    'Vanilla JavaScript (ES Modules)',
    'Plain CSS Custom Properties',
  ],
};

export function createDefaultPlayerData() {
  return {
    completedMissions: [],
    stars: {},
    bestScores: {},
    build: {
      wheels: false,
      scanner: false,
      battery: false,
      solar: false,
      dustCover: false,
      repairKits: false,
    },
    unlockedCodex: ['analog-sites'],
    achievements: [],
  };
}

export function createDefaultSettings(isSmallScreen = false) {
  return {
    music: true,
    sfx: true,
    quality: isSmallScreen ? 'Low' : 'Medium',
    callsign: 'ROVER01',
  };
}

export const DEMO_PLAYER_DATA = {
  completedMissions: ['training1', 'training2'],
  stars: {
    training1: 3,
    training2: 2,
  },
  bestScores: {
    training1: 1450,
    training2: 1180,
  },
  build: {
    wheels: true,
    scanner: true,
    battery: false,
    solar: true,
    dustCover: false,
    repairKits: false,
  },
  unlockedCodex: ['analog-sites', 'why-robots', 'battery-limits', 'radio-delay'],
  achievements: ['first-steps', 'round-trip'],
};
