/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {useEffect, useRef} from 'react';

interface HudApi {
  init: () => void;
  update: (data: Record<string, unknown>) => void;
  showMessage: (text: string, type: 'info' | 'warning' | 'danger') => void;
  onTerrainEvent: (type: 'too_steep' | 'boulder' | 'bump' | 'slip' | 'stuck') => void;
  show: () => void;
  hide: () => void;
}

declare global {
  interface Window {
    HUD?: HudApi;
  }
}

/**
 * Lightweight Martian terrain canvas backdrop for previewing the HUD overlay.
 * Allows mouse/touch drag panning so you can verify the HUD never blocks input,
 * and streams mock telemetry to window.HUD.update() until overridden with H-key Test Mode.
 */
export default function App() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const hud = window.HUD;
    if (hud) {
      hud.init();
      hud.show();
    }

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId = 0;
    let panX = 0;
    let panY = 0;
    let dragging = false;
    let lastMouseX = 0;
    let lastMouseY = 0;

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resize();
    window.addEventListener('resize', resize);

    const onPointerDown = (e: PointerEvent) => {
      dragging = true;
      lastMouseX = e.clientX;
      lastMouseY = e.clientY;
    };

    const onPointerMove = (e: PointerEvent) => {
      if (!dragging) return;
      panX += e.clientX - lastMouseX;
      panY += e.clientY - lastMouseY;
      lastMouseX = e.clientX;
      lastMouseY = e.clientY;
    };

    const onPointerUp = () => {
      dragging = false;
    };

    canvas.addEventListener('pointerdown', onPointerDown);
    window.addEventListener('pointermove', onPointerMove);
    window.addEventListener('pointerup', onPointerUp);

    const startTime = performance.now();
    const route = [
      {x: -55, z: 55},
      {x: -18, z: 24},
      {x: 15, z: -8},
      {x: 48, z: -48},
    ];

    const telemetry = {
      battery: 78,
      samples: 0,
      samplesNeeded: 1,
      score: 40,
      objective: 'Collect the layered rock',
      robot: {x: -35, z: 40, heading: 0.65},
      base: {x: -60, z: 60},
      goal: {x: 48, z: -48},
      worldBounds: {minX: -100, maxX: 100, minZ: -100, maxZ: 100},
      terrain: {slopeDeg: 12, speedMult: 0.8, batteryMult: 2, label: 'gentle'},
      stormSecondsLeft: null as number | null,
      stormActive: false,
      build: {
        battery: true,
        wheels: true,
        scanner: true,
        solar: false,
        dustCover: true,
        repairKits: 1,
      },
      route,
    };

    const renderFrame = (now: number) => {
      const t = (now - startTime) * 0.001;
      const w = canvas.width;
      const h = canvas.height;

      // Subtle Martian regolith backdrop
      ctx.fillStyle = '#3d1f14';
      ctx.fillRect(0, 0, w, h);

      // Perspective-style terrain contour grid (responds to pointer drag)
      ctx.strokeStyle = 'rgba(224, 122, 68, 0.22)';
      ctx.lineWidth = 1;
      const step = 48;
      const offsetX = ((panX % step) + step) % step;
      const offsetY = ((panY % step) + step) % step;

      ctx.beginPath();
      for (let x = offsetX; x < w; x += step) {
        ctx.moveTo(x, 0);
        ctx.lineTo(x, h);
      }
      for (let y = offsetY; y < h; y += step) {
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
      }
      ctx.stroke();

      // Gentle crater rings in center to illustrate unobstructed viewport
      const cx = w * 0.5 + panX * 0.6;
      const cy = h * 0.52 + panY * 0.6;
      ctx.strokeStyle = 'rgba(240, 148, 92, 0.28)';
      ctx.beginPath();
      ctx.arc(cx, cy, 110, 0, Math.PI * 2);
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(cx + 180, cy - 90, 58, 0, Math.PI * 2);
      ctx.stroke();

      // Subtle prompt in the lower center of the canvas layer (non-HUD preview helper)
      ctx.fillStyle = 'rgba(255, 255, 255, 0.5)';
      ctx.font = '12px system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('Drag canvas to test non-blocking overlay · Press H for HUD Test Mode', w * 0.5, h * 0.5);

      // Slowly orbit rover along the route for live preview
      const cycle = (Math.sin(t * 0.25) + 1) * 0.5;
      telemetry.robot.x = -55 + cycle * 88;
      telemetry.robot.z = 55 - cycle * 88;
      telemetry.robot.heading = 0.78 + Math.sin(t * 0.6) * 0.35;
      telemetry.battery = 78 - cycle * 12;
      telemetry.terrain.slopeDeg = Math.round(8 + Math.abs(Math.sin(t * 0.5)) * 14);
      telemetry.terrain.label = telemetry.terrain.slopeDeg > 17 ? 'steep' : 'gentle';
      telemetry.terrain.speedMult = telemetry.terrain.slopeDeg > 17 ? 0.6 : 0.8;
      telemetry.terrain.batteryMult = telemetry.terrain.slopeDeg > 17 ? 2 : 1.5;

      window.HUD?.update(telemetry);
      animId = requestAnimationFrame(renderFrame);
    };

    animId = requestAnimationFrame(renderFrame);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', resize);
      canvas.removeEventListener('pointerdown', onPointerDown);
      window.removeEventListener('pointermove', onPointerMove);
      window.removeEventListener('pointerup', onPointerUp);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="block h-screen w-screen cursor-grab active:cursor-grabbing select-none"
      aria-label="Martian terrain preview canvas"
    />
  );
}
