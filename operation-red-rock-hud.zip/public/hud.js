/* ==========================================================================
   Operation Red Rock — HUD Module (hud.js)
   Plain JavaScript, zero frameworks, zero build tools, zero localStorage.
   Exposes window.HUD as the single read-only display contract.

   Heading convention:
     robot.heading = 0 faces -Z (North / top of minimap).
     Positive radians rotate clockwise toward +X (East / right of minimap).
   ========================================================================== */

(function (global) {
  "use strict";

  /* === 1. STATE & DOM CACHE === */

  var dom = {};
  var initialized = false;
  var toastTimerId = null;
  var lastMinimapDrawMs = 0;
  var MINIMAP_INTERVAL_MS = 100; // Max 10 redraws per second

  // Cached formatted values so DOM writes only happen when values change
  var cache = {
    objective: null,
    batteryPct: null,
    batteryClass: null,
    sampleText: null,
    scoreText: null,
    stormClass: null,
    stormText: null,
    stormActive: null,
    slopeText: null,
    slopeLabel: null,
    slopeGradeClass: null,
    speedText: null,
    batteryMultText: null,
    targetDistText: null,
    targetAngleDeg: null,
    equipWheels: null,
    equipScanner: null,
    equipBattery: null,
    equipSolar: null,
    equipDustCover: null,
    equipRepairKits: null,
    equipEmpty: null
  };

  // Pre-allocated state flag for optional Test Mode (see section 7)
  var testModeActive = false;

  /* === 2. INITIALIZATION === */

  function cacheDom() {
    dom.root = document.getElementById("hud-root");
    dom.stormOverlay = document.getElementById("hud-storm-overlay");

    // Top-left: Mission
    dom.objective = document.getElementById("hud-objective-text");

    // Top-center: Status bar
    dom.batteryFill = document.getElementById("hud-battery-fill");
    dom.batteryPct = document.getElementById("hud-battery-pct");
    dom.samples = document.getElementById("hud-samples");
    dom.score = document.getElementById("hud-score");

    // Top-right: Minimap & Storm badge
    dom.minimap = document.getElementById("hud-minimap");
    dom.minimapCtx = dom.minimap ? dom.minimap.getContext("2d") : null;
    dom.stormBadge = document.getElementById("hud-storm-badge");
    dom.stormText = document.getElementById("hud-storm-text");

    // Bottom-left: Terrain
    dom.slopeDeg = document.getElementById("hud-slope-deg");
    dom.slopeLabel = document.getElementById("hud-slope-label");
    dom.speedMult = document.getElementById("hud-speed-mult");
    dom.batteryMult = document.getElementById("hud-battery-mult");

    // Bottom-center: Target direction
    dom.targetArrow = document.getElementById("hud-target-arrow");
    dom.targetDistance = document.getElementById("hud-target-distance");

    // Bottom-right: Equipment
    dom.equipWheels = document.getElementById("hud-equip-wheels");
    dom.equipScanner = document.getElementById("hud-equip-scanner");
    dom.equipBattery = document.getElementById("hud-equip-battery");
    dom.equipSolar = document.getElementById("hud-equip-solar");
    dom.equipDustCover = document.getElementById("hud-equip-dustCover");
    dom.equipRepair = document.getElementById("hud-equip-repair");
    dom.equipRepairCount = document.getElementById("hud-equip-repair-count");
    dom.equipEmpty = document.getElementById("hud-equip-empty");

    // Toast
    dom.toast = document.getElementById("hud-toast");
    dom.toastText = document.getElementById("hud-toast-text");
  }

  function formatMultiplier(value) {
    var rounded = Math.round(value * 10) / 10;
    return Number.isInteger(rounded) ? String(rounded) : rounded.toFixed(1);
  }

  function setTextIfChanged(el, key, nextText) {
    if (!el || cache[key] === nextText) return;
    cache[key] = nextText;
    el.textContent = nextText;
  }

  /* === 3. VISIBILITY === */

  function show() {
    if (!dom.root) cacheDom();
    if (dom.root) dom.root.classList.remove("is-hidden");
  }

  function hide() {
    if (!dom.root) cacheDom();
    if (dom.root) dom.root.classList.add("is-hidden");
  }

  /* === 4. MINIMAP === */

  function worldToMapX(wx, minX, spanX, pad, drawSize) {
    return pad + ((wx - minX) / spanX) * drawSize;
  }

  function worldToMapY(wz, minZ, spanZ, pad, drawSize) {
    return pad + ((wz - minZ) / spanZ) * drawSize;
  }

  var DEFAULT_BOUNDS = { minX: -100, maxX: 100, minZ: -100, maxZ: 100 };

  function drawMinimap(data, now) {
    if (!dom.minimapCtx || !dom.minimap) return;
    if (now - lastMinimapDrawMs < MINIMAP_INTERVAL_MS) return;
    lastMinimapDrawMs = now;

    var ctx = dom.minimapCtx;
    var w = dom.minimap.width;
    var h = dom.minimap.height;
    var pad = 10;
    var drawW = w - pad * 2;
    var drawH = h - pad * 2;

    var bounds = data.worldBounds || DEFAULT_BOUNDS;
    var spanX = bounds.maxX - bounds.minX || 1;
    var spanZ = bounds.maxZ - bounds.minZ || 1;

    // Clear background
    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = "#141418";
    ctx.fillRect(0, 0, w, h);

    // Play-area rectangle
    ctx.strokeStyle = "rgba(255, 255, 255, 0.3)";
    ctx.lineWidth = 1;
    ctx.strokeRect(pad + 0.5, pad + 0.5, drawW - 1, drawH - 1);

    // Optional planned route (dashed line)
    if (data.route && data.route.length > 1) {
      ctx.save();
      ctx.strokeStyle = "rgba(245, 158, 11, 0.75)";
      ctx.lineWidth = 1.5;
      ctx.setLineDash([4, 3]);
      ctx.beginPath();
      for (var i = 0; i < data.route.length; i++) {
        var pt = data.route[i];
        var rx = worldToMapX(pt.x, bounds.minX, spanX, pad, drawW);
        var ry = worldToMapY(pt.z, bounds.minZ, spanZ, pad, drawH);
        if (i === 0) ctx.moveTo(rx, ry);
        else ctx.lineTo(rx, ry);
      }
      ctx.stroke();
      ctx.restore();
    }

    // Lander / Base (square)
    if (data.base) {
      var bx = worldToMapX(data.base.x, bounds.minX, spanX, pad, drawW);
      var by = worldToMapY(data.base.z, bounds.minZ, spanZ, pad, drawH);
      ctx.fillStyle = "#38bdf8";
      ctx.fillRect(bx - 4, by - 4, 8, 8);
    }

    // Target / Goal (circle)
    if (data.goal) {
      var gx = worldToMapX(data.goal.x, bounds.minX, spanX, pad, drawW);
      var gy = worldToMapY(data.goal.z, bounds.minZ, spanZ, pad, drawH);
      ctx.fillStyle = "#f59e0b";
      ctx.beginPath();
      ctx.arc(gx, gy, 4.5, 0, Math.PI * 2);
      ctx.fill();
    }

    // Robot (arrow rotated to its heading; 0 = -Z / North on minimap)
    if (data.robot) {
      var px = worldToMapX(data.robot.x, bounds.minX, spanX, pad, drawW);
      var py = worldToMapY(data.robot.z, bounds.minZ, spanZ, pad, drawH);
      ctx.save();
      ctx.translate(px, py);
      ctx.rotate(data.robot.heading || 0);
      ctx.fillStyle = "#ffffff";
      ctx.beginPath();
      ctx.moveTo(0, -6.5);
      ctx.lineTo(4.5, 5);
      ctx.lineTo(0, 2.5);
      ctx.lineTo(-4.5, 5);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    }
  }

  /* === 5. UPDATE (CALLED EVERY FRAME) === */

  function applyUpdate(data) {
    if (!initialized || !data) return;

    // 1. Mission objective
    setTextIfChanged(dom.objective, "objective", data.objective || "");

    // 2. Battery, samples, score
    var rawBattery = typeof data.battery === "number" ? data.battery : 0;
    var clampedBattery = Math.max(0, Math.min(100, Math.round(rawBattery)));
    if (cache.batteryPct !== clampedBattery) {
      cache.batteryPct = clampedBattery;
      if (dom.batteryFill) dom.batteryFill.style.width = clampedBattery + "%";
      if (dom.batteryPct) dom.batteryPct.textContent = clampedBattery + "%";
    }

    var nextBatteryClass =
      clampedBattery < 20 ? "is-red" : clampedBattery <= 40 ? "is-amber" : "is-green";
    if (cache.batteryClass !== nextBatteryClass && dom.batteryFill) {
      cache.batteryClass = nextBatteryClass;
      dom.batteryFill.classList.remove("is-amber", "is-red");
      if (nextBatteryClass === "is-amber") dom.batteryFill.classList.add("is-amber");
      else if (nextBatteryClass === "is-red") dom.batteryFill.classList.add("is-red");
    }

    var samples = typeof data.samples === "number" ? Math.round(data.samples) : 0;
    var samplesNeeded = typeof data.samplesNeeded === "number" ? Math.round(data.samplesNeeded) : 1;
    setTextIfChanged(dom.samples, "sampleText", samples + "/" + samplesNeeded);

    var score = typeof data.score === "number" ? Math.round(data.score) : 0;
    setTextIfChanged(dom.score, "scoreText", String(score));

    // 3. Storm state & screen overlay
    var isStormActive = Boolean(data.stormActive);
    if (cache.stormActive !== isStormActive && dom.stormOverlay) {
      cache.stormActive = isStormActive;
      dom.stormOverlay.classList.toggle("is-active", isStormActive);
    }

    var nextStormClass = "is-hidden";
    var nextStormText = "";
    if (isStormActive) {
      nextStormClass = "is-danger";
      nextStormText = "Dust storm active";
    } else if (typeof data.stormSecondsLeft === "number" && data.stormSecondsLeft >= 0) {
      nextStormClass = "is-warning";
      nextStormText = "Storm in " + Math.ceil(data.stormSecondsLeft) + " s";
    }

    if (cache.stormClass !== nextStormClass && dom.stormBadge) {
      cache.stormClass = nextStormClass;
      dom.stormBadge.classList.remove("is-hidden", "is-warning", "is-danger");
      dom.stormBadge.classList.add(nextStormClass);
    }
    setTextIfChanged(dom.stormText, "stormText", nextStormText);

    // 4. Terrain telemetry
    var terrain = data.terrain;
    if (terrain) {
      var slopeDeg = Math.round(terrain.slopeDeg || 0);
      setTextIfChanged(dom.slopeDeg, "slopeText", slopeDeg + "\u00B0");

      var labelStr = String(terrain.label || "flat");
      setTextIfChanged(dom.slopeLabel, "slopeLabel", labelStr);

      var lowerLabel = labelStr.toLowerCase();
      var nextGradeClass =
        lowerLabel.indexOf("too") !== -1
          ? "is-too-steep"
          : lowerLabel.indexOf("steep") !== -1
          ? "is-steep"
          : "";
      if (cache.slopeGradeClass !== nextGradeClass && dom.slopeLabel) {
        cache.slopeGradeClass = nextGradeClass;
        dom.slopeLabel.classList.remove("is-steep", "is-too-steep");
        if (nextGradeClass) dom.slopeLabel.classList.add(nextGradeClass);
      }

      var speedStr = "Speed x" + formatMultiplier(terrain.speedMult != null ? terrain.speedMult : 1);
      setTextIfChanged(dom.speedMult, "speedText", speedStr);

      var battMultStr =
        "Battery use x" + formatMultiplier(terrain.batteryMult != null ? terrain.batteryMult : 1);
      setTextIfChanged(dom.batteryMult, "batteryMultText", battMultStr);
    }

    // 5. Target distance & relative bearing computed inside HUD
    if (data.robot && data.goal) {
      var dx = data.goal.x - data.robot.x;
      var dz = data.goal.z - data.robot.z;
      var dist = Math.round(Math.hypot(dx, dz));
      setTextIfChanged(dom.targetDistance, "targetDistText", "Target " + dist + " m");

      var worldAngle = Math.atan2(dx, -dz);
      var relRad = worldAngle - (data.robot.heading || 0);
      var relDeg = Math.round((relRad * 180) / Math.PI);
      if (cache.targetAngleDeg !== relDeg && dom.targetArrow) {
        cache.targetAngleDeg = relDeg;
        dom.targetArrow.style.transform = "rotate(" + relDeg + "deg)";
      }
    }

    // 6. Equipment list (show only items present in build)
    var build = data.build;
    if (build) {
      var hasWheels = Boolean(build.wheels);
      var hasScanner = Boolean(build.scanner);
      var hasBattery = Boolean(build.battery);
      var hasSolar = Boolean(build.solar);
      var hasDustCover = Boolean(build.dustCover);
      var repairCount = typeof build.repairKits === "number" ? Math.max(0, Math.round(build.repairKits)) : 0;

      if (cache.equipWheels !== hasWheels && dom.equipWheels) {
        cache.equipWheels = hasWheels;
        dom.equipWheels.classList.toggle("is-hidden", !hasWheels);
      }
      if (cache.equipScanner !== hasScanner && dom.equipScanner) {
        cache.equipScanner = hasScanner;
        dom.equipScanner.classList.toggle("is-hidden", !hasScanner);
      }
      if (cache.equipBattery !== hasBattery && dom.equipBattery) {
        cache.equipBattery = hasBattery;
        dom.equipBattery.classList.toggle("is-hidden", !hasBattery);
      }
      if (cache.equipSolar !== hasSolar && dom.equipSolar) {
        cache.equipSolar = hasSolar;
        dom.equipSolar.classList.toggle("is-hidden", !hasSolar);
      }
      if (cache.equipDustCover !== hasDustCover && dom.equipDustCover) {
        cache.equipDustCover = hasDustCover;
        dom.equipDustCover.classList.toggle("is-hidden", !hasDustCover);
      }
      if (cache.equipRepairKits !== repairCount) {
        cache.equipRepairKits = repairCount;
        if (dom.equipRepair) dom.equipRepair.classList.toggle("is-hidden", repairCount <= 0);
        if (dom.equipRepairCount) dom.equipRepairCount.textContent = "x" + repairCount;
      }

      var isEmpty =
        !hasWheels && !hasScanner && !hasBattery && !hasSolar && !hasDustCover && repairCount <= 0;
      if (cache.equipEmpty !== isEmpty && dom.equipEmpty) {
        cache.equipEmpty = isEmpty;
        dom.equipEmpty.classList.toggle("is-hidden", !isEmpty);
      }
    }

    // 7. Throttled minimap draw
    drawMinimap(data, performance.now());
  }

  function update(data) {
    if (testModeActive) return;
    applyUpdate(data);
  }

  /* === 6. MESSAGES (TOASTS & TERRAIN EVENTS) === */

  function showMessage(text, type) {
    if (!initialized) cacheDom();
    if (!dom.toast || !dom.toastText) return;

    if (toastTimerId !== null) {
      clearTimeout(toastTimerId);
      toastTimerId = null;
    }

    var safeType = type === "warning" || type === "danger" ? type : "info";
    dom.toast.classList.remove("is-info", "is-warning", "is-danger", "is-visible");
    dom.toast.classList.add("is-" + safeType);
    dom.toastText.textContent = String(text || "");
    dom.toast.classList.add("is-visible");

    toastTimerId = setTimeout(function () {
      dom.toast.classList.remove("is-visible");
      toastTimerId = null;
    }, 3000);
  }

  function onTerrainEvent(type) {
    switch (type) {
      case "too_steep":
        showMessage("Too steep, find another route", "danger");
        break;
      case "boulder":
        showMessage("Boulder ahead", "warning");
        break;
      case "bump":
        showMessage("Minor impact detected", "info");
        break;
      case "slip":
        showMessage("Wheels slipping on loose sand", "warning");
        break;
      case "stuck":
        showMessage("Robot stuck, use the repair kit", "danger");
        break;
      default:
        break;
    }
  }

  /* === 7. TEST MODE ("H" KEY — REMOVE THIS SECTION IF NOT NEEDED) === */

  var testPanelEl = null;
  var testState = {
    battery: 78,
    samples: 0,
    samplesNeeded: 1,
    score: 40,
    objective: "Collect the layered rock",
    robot: { x: -20, z: 30, heading: 0.4 },
    base: { x: -60, z: 60 },
    goal: { x: 45, z: -45 },
    worldBounds: { minX: -100, maxX: 100, minZ: -100, maxZ: 100 },
    terrain: { slopeDeg: 12, speedMult: 0.8, batteryMult: 2, label: "gentle" },
    stormSecondsLeft: null,
    stormActive: false,
    build: {
      battery: true,
      wheels: true,
      scanner: true,
      solar: false,
      dustCover: true,
      repairKits: 1
    },
    route: [
      { x: -20, z: 30 },
      { x: 10, z: 0 },
      { x: 45, z: -45 }
    ]
  };

  function slopeToTerrain(deg) {
    if (deg < 8) return { slopeDeg: deg, speedMult: 1, batteryMult: 1, label: "flat" };
    if (deg < 18) return { slopeDeg: deg, speedMult: 0.8, batteryMult: 1.5, label: "gentle" };
    if (deg < 28) return { slopeDeg: deg, speedMult: 0.5, batteryMult: 2, label: "steep" };
    return { slopeDeg: deg, speedMult: 0.2, batteryMult: 3, label: "too steep" };
  }

  function pushTestState() {
    testModeActive = true;
    applyUpdate(testState);
  }

  function buildTestPanel() {
    if (testPanelEl) return;

    var panel = document.createElement("aside");
    panel.id = "hud-test-panel";
    panel.className = "hud-test-panel is-hidden";
    panel.setAttribute("aria-label", "HUD Test Controls");

    panel.innerHTML =
      '<div class="hud-test-header">' +
      '  <h2 class="hud-test-title">HUD Test Mode (H)</h2>' +
      '  <button type="button" class="hud-test-close" id="hud-test-close">Close</button>' +
      "</div>" +
      '<div class="hud-test-group">' +
      '  <div class="hud-test-row">' +
      '    <label for="ht-batt">Battery: <strong id="ht-batt-val">78%</strong></label>' +
      '    <input id="ht-batt" type="range" min="0" max="100" value="78" />' +
      "  </div>" +
      '  <div class="hud-test-row">' +
      '    <label for="ht-slope">Slope: <strong id="ht-slope-val">12&deg;</strong></label>' +
      '    <input id="ht-slope" type="range" min="0" max="40" value="12" />' +
      "  </div>" +
      '  <div class="hud-test-row">' +
      '    <label for="ht-storm-cd">Storm countdown (s):</label>' +
      '    <input id="ht-storm-cd" type="range" min="0" max="60" value="0" />' +
      '    <span id="ht-storm-cd-val">Off</span>' +
      "  </div>" +
      '  <label class="hud-test-check">' +
      '    <input id="ht-storm-active" type="checkbox" /> Dust storm active' +
      "  </label>" +
      "</div>" +
      '<div class="hud-test-group">' +
      '  <span class="hud-label">Toasts</span>' +
      '  <div class="hud-test-buttons">' +
      '    <button type="button" class="hud-test-btn" data-toast="info">Info</button>' +
      '    <button type="button" class="hud-test-btn" data-toast="warning">Warning</button>' +
      '    <button type="button" class="hud-test-btn" data-toast="danger">Danger</button>' +
      '    <button type="button" class="hud-test-btn" data-terrain="boulder">Boulder</button>' +
      '    <button type="button" class="hud-test-btn" data-terrain="stuck">Stuck</button>' +
      "  </div>" +
      "</div>" +
      '<div class="hud-test-group">' +
      '  <span class="hud-label">Equipment</span>' +
      '  <div class="hud-test-checks">' +
      '    <label class="hud-test-check"><input type="checkbox" data-equip="wheels" checked /> Off-road wheels</label>' +
      '    <label class="hud-test-check"><input type="checkbox" data-equip="scanner" checked /> Scanner</label>' +
      '    <label class="hud-test-check"><input type="checkbox" data-equip="battery" checked /> Large battery</label>' +
      '    <label class="hud-test-check"><input type="checkbox" data-equip="solar" /> Solar panel</label>' +
      '    <label class="hud-test-check"><input type="checkbox" data-equip="dustCover" checked /> Dust cover</label>' +
      '    <label class="hud-test-check"><input type="checkbox" data-equip="repairKits" checked /> Repair kit x1</label>' +
      "  </div>" +
      "</div>" +
      '<div class="hud-test-buttons">' +
      '  <button type="button" class="hud-test-btn" id="ht-resume-game">Resume Live Data</button>' +
      "</div>";

    document.body.appendChild(panel);
    testPanelEl = panel;

    var battInput = document.getElementById("ht-batt");
    var battVal = document.getElementById("ht-batt-val");
    battInput.addEventListener("input", function () {
      testState.battery = Number(battInput.value);
      battVal.textContent = testState.battery + "%";
      pushTestState();
    });

    var slopeInput = document.getElementById("ht-slope");
    var slopeVal = document.getElementById("ht-slope-val");
    slopeInput.addEventListener("input", function () {
      var deg = Number(slopeInput.value);
      slopeVal.textContent = deg + "\u00B0";
      testState.terrain = slopeToTerrain(deg);
      pushTestState();
    });

    var stormCdInput = document.getElementById("ht-storm-cd");
    var stormCdVal = document.getElementById("ht-storm-cd-val");
    stormCdInput.addEventListener("input", function () {
      var sec = Number(stormCdInput.value);
      testState.stormSecondsLeft = sec > 0 ? sec : null;
      stormCdVal.textContent = sec > 0 ? sec + " s" : "Off";
      pushTestState();
    });

    var stormActiveInput = document.getElementById("ht-storm-active");
    stormActiveInput.addEventListener("change", function () {
      testState.stormActive = stormActiveInput.checked;
      pushTestState();
    });

    panel.addEventListener("click", function (e) {
      var target = e.target;
      if (!target || !target.dataset) return;
      if (target.dataset.toast === "info") showMessage("Sample collected", "info");
      else if (target.dataset.toast === "warning") showMessage("Battery low", "warning");
      else if (target.dataset.toast === "danger") showMessage("Too steep, find another route", "danger");
      else if (target.dataset.terrain) onTerrainEvent(target.dataset.terrain);
    });

    var equipInputs = panel.querySelectorAll("input[data-equip]");
    for (var i = 0; i < equipInputs.length; i++) {
      equipInputs[i].addEventListener("change", function (e) {
        var key = e.target.dataset.equip;
        if (key === "repairKits") {
          testState.build.repairKits = e.target.checked ? 1 : 0;
        } else {
          testState.build[key] = e.target.checked;
        }
        pushTestState();
      });
    }

    document.getElementById("ht-resume-game").addEventListener("click", function () {
      testModeActive = false;
      panel.classList.add("is-hidden");
    });

    document.getElementById("hud-test-close").addEventListener("click", function () {
      panel.classList.add("is-hidden");
    });
  }

  function onKeyDown(e) {
    if (e.key !== "h" && e.key !== "H") return;
    var tag = e.target && e.target.tagName;
    if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
    if (!testPanelEl) buildTestPanel();
    var isHidden = testPanelEl.classList.toggle("is-hidden");
    if (!isHidden && !testModeActive) {
      pushTestState();
    }
  }

  /* === PUBLIC INIT === */

  function init() {
    cacheDom();
    if (!initialized) {
      initialized = true;
      global.addEventListener("keydown", onKeyDown);
    }
  }

  global.HUD = {
    init: init,
    update: update,
    showMessage: showMessage,
    onTerrainEvent: onTerrainEvent,
    show: show,
    hide: hide
  };
})(window);
